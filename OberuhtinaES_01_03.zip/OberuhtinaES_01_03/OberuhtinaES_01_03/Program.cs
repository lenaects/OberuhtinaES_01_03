﻿using OberuhtinaES_01_03.Class;
using System.Xml.Linq;
//автоматическое заполнение
Otdel otdel = new Otdel("Тестирование", 5000.67, 3.4);
otdel.DisplayInfo();
Descendant descendant = new Descendant("Разработка", 10000, 4.5, 2);
descendant.DisplayInfo(); 
//ввод с клавиатуры
try
{
    Console.WriteLine("Заполнение базового класса:");
    Console.Write("Название:");
    string nameBasic=Console.ReadLine();
    double basicsalary = ReadDouble("Базовый оклад:");
    double coefficientBasic = ReadDouble("Коэффициент:");
    Otdel otdel2 = new Otdel(nameBasic, basicsalary, coefficientBasic);
    otdel2.DisplayInfo();
    Console.WriteLine("Заполнение класса потомка:");
    Console.Write("Название:");
    string nameDescendant = Console.ReadLine();
    double basicsalaryDescendant = ReadDouble("Базовый оклад:");
    double coefficientDescendant = ReadDouble("Коэффициент:");
    int harmfulness = ReadInt("Вредность:");
    Descendant descendant2 = new Descendant(nameDescendant, basicsalaryDescendant, coefficientDescendant, harmfulness);
    descendant2.DisplayInfo();
}
catch(Exception ex)
{
    Console.WriteLine(ex.Message);
}
//проверка ввода числа
static int ReadInt(string msg)
{
    int rezult;
    while (true)
    {
        Console.Write(msg);
        if(int.TryParse(Console.ReadLine(), out rezult))
        {
            break;
        }
        Console.WriteLine("Некоректный ввод(Введите целое число)");
    }
    return rezult;
}
//проверка ввода числа
static double ReadDouble(string msg)
{
    double rezult;
    while (true)
    {
        Console.Write(msg);
        if (double.TryParse(Console.ReadLine(), out rezult))
        {
            break;
        }
        Console.WriteLine("Некоректный ввод(Введите число)");
    }
    return rezult;
}