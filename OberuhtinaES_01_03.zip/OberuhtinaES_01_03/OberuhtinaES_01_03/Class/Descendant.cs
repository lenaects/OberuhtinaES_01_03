﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OberuhtinaES_01_03.Class
{
    public class Descendant : Otdel
    {
        public int Harmfulness { get; set; }
        public Descendant(string name, double basicsalary, double coefficient, int harmfulness) : base(name, basicsalary, coefficient)
        {
            Harmfulness = harmfulness;
        }
        public override double Calculate()
        {
            double calculate = base.Calculate();
            double Qp = Harmfulness < 3 ? calculate + calculate * Harmfulness : calculate + calculate * 1.5 * Harmfulness;
            return Qp;
        }
        public override void DisplayInfo()
        {
            Console.WriteLine($"Название:{Name}\nБазовый оклад:{BasicSalary}\nКоэффициент:{Coefficient}\nВредность:{Harmfulness}\nРезультат:{Calculate()}");
        }
    }
}
