﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OberuhtinaES_01_03.Class
{
    public class Otdel
    {
        public string Name { get; set; }
        public double BasicSalary { get; set; }
        public double Coefficient { get; set; }
        public Otdel(string name, double basicsalary, double coefficient)
        {
            Name = name;
            BasicSalary = basicsalary;
            Coefficient = coefficient;
        }
        public virtual double Calculate()
        {
            double Q = BasicSalary * (100 + Coefficient);
            return Q;
        }
        public virtual void DisplayInfo()
        {
            Console.WriteLine($"Название:{Name}\nБазовый оклад:{BasicSalary}\nКоэффициент:{Coefficient}\nРезультат:{Calculate()}");

        }
    }
}
